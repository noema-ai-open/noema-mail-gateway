# NOEMA Android TV Tour Speed Limiter

A small Android TV bandwidth controller for travel, rehab, hotels and other metered connections.

## Profiles

- **2 Mbit/s — Saver**
- **4 Mbit/s — Balanced**
- **6 Mbit/s — Comfort**
- **Full Speed — Home**

The limiter applies one aggregate **download** ceiling across the device. Upload remains unrestricted. Full Speed stops the local VPN completely.

## How it works

Android does not expose a normal per-device traffic-shaping API to third-party apps. NOEMA uses Android `VpnService` to create a local TUN interface. `hev-socks5-tunnel` converts TUN packets to SOCKS5 traffic. A local SOCKS5 server then opens protected direct internet sockets and applies one process-wide rate limiter to all returning TCP and UDP traffic. No external VPN server is used and traffic is not decrypted or inspected.

TCP CONNECT and UDP ASSOCIATE are supported, including UDP/QUIC traffic used by modern streaming apps.

## Install

1. Install the APK on Android TV / Google TV / Xiaomi TV Stick using ADB, Downloader, Send Files to TV or another sideload method.
2. Open **NOEMA TV Speed Limiter**.
3. Select 2, 4 or 6 Mbit/s.
4. Android asks once for permission to create a VPN connection. Accept it.
5. Choose **Full Speed** to stop the limiter.

## Status

`0.1.0-alpha1` is the first hardware-test build. It is intentionally marked alpha until tested on real Xiaomi / Android TV hardware.

The current CI build is test-signed. A stable public release should use a persistent private signing key before wider distribution.

## Privacy

- No analytics
- No account
- No external VPN endpoint
- No payload inspection
- No telemetry

## Dependency

Uses `com.wgtunnel:hevtunnel` / hev-socks5-tunnel under the MIT License.

## License

MIT
